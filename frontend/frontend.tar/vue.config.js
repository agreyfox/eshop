module.exports = {
  runtimeCompiler: true,
  publicPath: '/admin/pages/'
}